# MTI_Assignment
This is a take home assignment
